/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

package net.sourceforge.pmd.lang.apex.rule.security;

import net.sourceforge.pmd.testframework.PmdRuleTst;


public class ApexCRUDViolationTest extends PmdRuleTst {
    // no additional unit tests

}
