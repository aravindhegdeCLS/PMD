/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

package net.sourceforge.pmd.lang.apex.rule.codestyle;

import net.sourceforge.pmd.testframework.PmdRuleTst;

public class FormalParameterNamingConventionsTest extends PmdRuleTst {
    // no additional unit tests
}
