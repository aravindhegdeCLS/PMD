package net.sourceforge.pmd.lang.apex.rule.performance;

import net.sourceforge.pmd.testframework.PmdRuleTst;

public class AvoidUpdateForContractTest extends PmdRuleTst{

}
