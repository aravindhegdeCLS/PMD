package net.sourceforge.pmd.lang.apex.rule.performance;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.pmd.lang.apex.ast.ASTMethodCallExpression;
import net.sourceforge.pmd.lang.apex.rule.AbstractApexRule;

public class UseUtilityFunctionRule extends AbstractApexRule{
	List<String>listOfMethods=new ArrayList<>();
	public UseUtilityFunctionRule() {
		listOfMethods.add("getNextCycleDate");
		listOfMethods.add("addMnths");
		listOfMethods.add("cyclesBetween");
		listOfMethods.add("getAccrualDays");
		listOfMethods.add("getEndDateForArrearsContractAndFirstPmtDate");
		listOfMethods.add("getEndDateFromFirstPmtDateForArrearContract");
		listOfMethods.add("getStartDateForArrears");
	}
	@Override
    public Object visit(ASTMethodCallExpression node, Object data) {
		String methodname=node.getMethodName();
		if(listOfMethods.contains(node.getMethodName())) {
			if(!node.getFullMethodName().equals("loan.DateUtil."+node.getMethodName())) {
				addViolation(data,node);
			}
		}
		else if(methodname.matches("(.*)Next(.*)Cycle(.*)Date(.*)")) {
				addViolation(data,node);
		}
		else if(methodname.matches("(.*)Cycle(.*)Date(.*)")) {
			addViolation(data,node);
	}
        return data;
    }
}
