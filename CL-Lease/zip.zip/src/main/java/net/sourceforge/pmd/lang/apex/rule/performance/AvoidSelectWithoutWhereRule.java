package net.sourceforge.pmd.lang.apex.rule.performance;

import net.sourceforge.pmd.lang.apex.ast.ASTSoqlExpression;
import net.sourceforge.pmd.lang.apex.rule.AbstractApexRule;

public class AvoidSelectWithoutWhereRule extends AbstractApexRule{
	@Override
    public Object visit(ASTSoqlExpression node, Object data) {
		String soql=node.getQuery().toLowerCase();
		if(soql.contains("select")&&!soql.contains("where")) {
			addViolation(data, node);
		}
        return data;
    }
}
