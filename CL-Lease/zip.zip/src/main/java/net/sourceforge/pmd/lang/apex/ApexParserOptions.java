/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

package net.sourceforge.pmd.lang.apex;

import net.sourceforge.pmd.lang.ParserOptions;

public class ApexParserOptions extends ParserOptions {

    // empty class for now, since we don't have extra options for Apex
    // Once you add something here, make sure to override hashCode and equals

}
