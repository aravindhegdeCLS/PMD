package net.sourceforge.pmd.lang.apex.rule.performance;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.pmd.lang.apex.ast.ASTMethodCallExpression;
import net.sourceforge.pmd.lang.apex.ast.ASTVariableExpression;
import net.sourceforge.pmd.lang.apex.rule.AbstractApexRule;

public class UseLoanConstantsForPicklistValuesRule extends AbstractApexRule{
	List<String>listOfValues=new ArrayList<>();
	public UseLoanConstantsForPicklistValuesRule(){
		listOfValues.add("LOAN_PAYMENT_FREQ_MONTHLY");
	}
	
	@Override
    public Object visit(ASTVariableExpression node, Object data) {
		
        return data;
    }
}
